# Write a set called `snacks` that includes at least 3 of your favorite snack foods.

# Problem Solution:

favSnacks = {"Doritos", "gummi bears", "Bacon flavored sunflower seeds"}

print("My favorite snacks are: " + favSnacks)