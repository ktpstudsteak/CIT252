# Doctor Who needs help keeping track of who's next in line. He keeps losing his printout and would like to have it digitally. 
# Create a queue that will store the names of any patient names supplied.


# ** FINISH WRITING CODE **