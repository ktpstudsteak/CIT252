# Here is an example of a binary search tree:

# ** FINISH WRITING CODE **