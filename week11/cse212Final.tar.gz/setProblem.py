# Write a set called `snacks` that includes at least 3 of your favorite snack foods.
# Write a set called `snacks` that includes at least 3 of your favorite snack foods.

# Problem Solution:

# ** FINISH WRITING CODE **