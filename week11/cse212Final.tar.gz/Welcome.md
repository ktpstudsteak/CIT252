Welcome

# Python Tutorial

## Welcome
Welcome to the tutorial! This guide will go over different data structures in Python and provide examples on their use cases.
### Introduction

This is the final project for CSE212. It is a guide that walks you through queues, sets, and trees in Python. This guide will be specific to Python 3.


### Credit 
<!--  Keep if needed -->
Guide written by Kaden Payne.
