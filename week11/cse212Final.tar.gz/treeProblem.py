# Write a problem about adding items to and traversing a tree
# Write code for the problem

# ** FINISH WRITING CODE **