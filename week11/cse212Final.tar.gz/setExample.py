# Note the two "apple" items. When you print, how many "apples" are there?

thisset = {"apple", "banana", "cherry", "apple"}

print(thisset)