pet_one : dict = {
    'Type' : 'Cat',
    'Color' : 'White',
    'Nickname' : 'Oliver',
    'Owner' : 'Sam'
}
pet_two : dict = {
    'Type' : 'Dog',
    'Color' : 'Brown',
    'Nickname' : 'Rocko',
    'Owner' : 'Ryan'
}

def dictIterate(dict_obj : dict) -> None:
    for key in dict_obj:
        value : str = dict_obj[key]
        print(key, ':', value)

dictIterate(pet_one)
dictIterate(pet_two)

print('\n')

england : dict = {'Capital' : 'London'}
france : dict = {'Capital' : 'Paris'}
belgium : dict = {'Capital' : 'Brussels'}

def dictCityInfo(city : dict, pop : int, fact : str, lang : str):
    city['Population (in millions)'] = pop
    city['Fact'] = fact
    city['Language'] = lang

dictCityInfo(england, 53.01, 'The name "England" is derived from the Old English name Englaland, which means "land of the Angles".', 'English')
dictCityInfo(france, 66.9, 'Originally applied to the whole Frankish Empire, the name France comes from the Latin Francia, or "realm of the Franks".', 'French')
dictCityInfo(belgium, 11.35, 'Caesar used the word "Belgium" once, to refer to their region.', 'Dutch')

dictIterate(england)
dictIterate(france)
dictIterate(belgium)

print('\n')

pizza_order : dict = {
    'Name' : 'Ryan',
     'Size' : 'Large',
     'Crust' : 'Thin',
     'Toppings' : ['Peporoni', 'Sausage', 'Pineapple']
}

print(str.format('Thank you for your order {}', pizza_order.get('Name')))
print(str.format('You have ordered a {}, {}-crust pizza with the following toppings:', pizza_order.get('Size'), pizza_order.get('Crust')))
print(str.format('{}', pizza_order.get('Toppings')))