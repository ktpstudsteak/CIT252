############
## Part 1 ##
############
names : list = ['Kurt', 'David', 'Kathrine']

[print(str.format('Where is {} today?', name)) for name in names]
print('\n')

############
## Part 2 ##
############
my_favorite_cars : list = ['car', 'truck', 'semi-truck']
my_favorite_flowers : list = ['rose', 'daisy', 'lilly', 'sunflower']
my_favorite_animals : list = ['lion', 'wolf', 'cat', 'zedbra', 'chicken']

my_favorite_things : list = [my_favorite_cars, my_favorite_flowers, my_favorite_animals]
even_list : list = []
odd_list : list = []

def filterList(items : list = [[item for item in items] for items in my_favorite_things]) -> None:
    for item in items:
        [filterList(item) if type(item) == list else [even_list.append(item) if len(item) % 2 == 0 else odd_list.append(item)]]

def printList(items : list = []):
    [print(item) for item in items]

filterList()

print('My favorite even items are: ')
printList(even_list)
print('\n')
print('My favorite odd items are: ')
printList(odd_list)
print('\n')

############
## Part 3 ##
############
for num in range(1, 21):
    if (num % 3 == 0 and num % 5 == 0):
        print('ZipZap')
    else:
        [print('Zip') if num % 3 == 0 else [print('Zap') if num % 5 == 0 else print(num)]]
    